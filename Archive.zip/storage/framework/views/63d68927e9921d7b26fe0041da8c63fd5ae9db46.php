<?php $__env->startSection('title','Login'); ?>
<?php $__env->startSection('content'); ?>

<div class="form-holder">
   <?php if(session('sukses')): ?>
   <div class="form-row">
      <div class="my-3 offset-4 col-md-4">
         <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Congratulations!</strong> <?php echo e(session('sukses')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
               <span aria-hidden="true">&times;</span>
            </button>
         </div>
      </div>
   </div>
   <?php endif; ?>
   <div class="form-content">
      <div class="form-items">
         <h3>Login to account</h3>
         <p>Login to your Branchlink.in admin</p>
         <form action="/login" method="POST">
            <?php echo csrf_field(); ?>
            <input class="form-control" type="text" name="username" placeholder="Username" required>
            <input class="form-control" type="password" name="password" placeholder="Password" required>
            <div class="form-button">
               <button id="submit" type="submit" class="ibtn">Login</button> <a href="/register">Don't have an
                  account?</a>
            </div>
         </form>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('login.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bintangtobing/Documents/GitHub/branchlink.in/branchlink.in/resources/views/login/signin.blade.php ENDPATH**/ ?>