<!DOCTYPE HTML>
<html>


<head>
   <?php $__currentLoopData = $userlink->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemlink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <title><?php echo e($itemlink->titlepage); ?> - <?php echo e($itemlink->name); ?></title>
   <link rel="icon" href="<?php echo asset('images/icon.png'); ?>">
   <meta charset="utf-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
   <link rel="stylesheet" href="<?php echo asset('username/assets/css/main.css'); ?>" />
   <link rel="stylesheet" href="<?php echo asset('username/assets/css/custom.css'); ?>" />
   <noscript>
      <link rel="stylesheet" href="<?php echo asset('username/assets/css/noscript.css'); ?>" /></noscript>

   
   <meta name="title" content="<?php echo e($itemlink->titlepage); ?> - <?php echo e($itemlink->name); ?>">
   <meta name="keywords" content="<?php echo e($itemlink->titlepage); ?>, <?php echo e($itemlink->name); ?>">
   <meta name="description"
      content="Take your any link to branchlink, to discover all of your content. And help them to find you.">
   <meta name="author" content="Branchlink.in from Sarjanamalam">
   <meta name="robots" content="index, follow">
   <meta name="language" content="English">

   
   
   <meta property="fb:admins" content="111044563749542">
   <meta property="og:title" content="<?php echo e($itemlink->titlepage); ?> - <?php echo e($itemlink->name); ?>">
   <meta property="og:type" content="website">
   <meta property="og:url" content="<?php echo e(URL::current()); ?>">
   <meta property="og:image" content="<?php echo asset('storage/img/covermcan.jpg'); ?>">
   <meta property="og:description"
      content="Take your any link to branchlink, to discover all of your content. And help them to find you.">
   <meta property="og:site_name" content="<?php echo e($itemlink->name); ?>.">
   <!-- Twitter -->
   <meta property="twitter:card" content="summary_large_image">
   <meta property="twitter:url" content="<?php echo e(URL::current()); ?>">
   <meta property="twitter:title" content="<?php echo e($itemlink->titlepage); ?> - <?php echo e($itemlink->name); ?>">
   <meta property="twitter:description"
      content="<?php echo e($itemlink->name); ?> page is made for personal creative curriculum vitae. Also for personal satisfaction and personal completeness in this digital age.">
   <meta property="twitter:image" content="<?php echo asset('storage/img/covermcan.jpg'); ?>">
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</head>

<body class="is-preload">
   <!-- Wrapper -->
   <div id="wrapper">
      <!-- Header -->
      <header id="header" class="alt">
         <?php $__currentLoopData = $userlink->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linkss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <span class="logo"><img src="<?php echo asset('media/'.$linkss->avatar); ?>"
               alt="Display picture <?php echo e($linkss->name); ?>" /></span>
         <p><?php echo e($linkss->titlepage); ?>.</p>
         <p>Made by <a href="<?php echo e($linkss->instagram); ?>">@ <?php echo e($linkss->username); ?></a>
         </p>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </header>
      <!-- Introduction -->
      <?php $__currentLoopData = $userlink; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <section id="askfm">
         <ul class="actions fit">
            
            <li><a target="_blank" href="<?php echo e($link->link); ?>" class="button large fit askfm-theme"><?php echo e($link->title); ?>

               </a></li>
         </ul>
      </section>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php $__currentLoopData = $userlink->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linkfooter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <!-- Footer -->
      <footer id="footer">
         <section>
            <h2>Wanna be friends?</h2>
            <dl class="alt">
               <dt>Email</dt>
               <dd><a href="mailto:<?php echo e($linkfooter->email); ?>"><?php echo e($linkfooter->email); ?></a></dd>
            </dl>
            <ul class="icons">
               <li><a href="https://<?php echo e($linkfooter->twitter); ?>" class="icon brands fa-twitter alt"><span
                        class="label">Twitter</span></a>
               </li>
               <li><a href="https://<?php echo e($linkfooter->facebook); ?>" class="icon brands fa-facebook-f alt"><span
                        class="label">Facebook</span></a>
               </li>
               <li><a href="https://<?php echo e($linkfooter->instagram); ?>" class="icon brands fa-instagram alt"><span
                        class="label">Instagram</span></a>
               </li>
            </ul>
         </section>
         <?php $year = date('Y'); ?>
         <p class="copyright">&copy; <?php echo e($linkfooter->name); ?> <?php echo e($year); ?> - Branchlink.in from Sarjanamalam.</p>
      </footer>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   </div>

   <!-- Scripts -->
   <script src="<?php echo asset('username/assets/js/jquery.min.js'); ?>"></script>
   <script src="<?php echo asset('username/assets/js/jquery.scrollex.min.js'); ?>"></script>
   <script src="<?php echo asset('username/assets/js/jquery.scrolly.min.js'); ?>"></script>
   <script src="<?php echo asset('username/assets/js/browser.min.js'); ?>"></script>
   <script src="<?php echo asset('username/assets/js/breakpoints.min.js'); ?>"></script>
   <script src="<?php echo asset('username/assets/js/util.js'); ?>"></script>
   <script src="<?php echo asset('username/assets/js/main.js'); ?>"></script>
   <script>
      $(document).ready(function () {
         $.ajaxSetup({
            headers: {
               'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
         });
         $('a.linkurl').on('click', function (e) {
            var el = $(this);
            $.ajax({
               type: "POST",
               url: el.attr('href'),
               data: {
                  value: el.attr('data-id')
               },
               success: function (data) {
                  console.log(data);
               }
            });
            e.preventDefault();
         });
      });
   </script>

</body>

</html><?php /**PATH /Users/bintangtobing/Documents/GitHub/branchlink.in/branchlink.in/resources/views/result/index.blade.php ENDPATH**/ ?>