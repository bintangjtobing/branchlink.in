<?php $__env->startSection('title','Register'); ?>
<?php $__env->startSection('content'); ?>
<?php $tokens =  bin2hex(openssl_random_pseudo_bytes(64));?>
<div class="form-holder">
   <div class="form-content">
      <div class="form-items">
         <h3>Register account</h3>
         <p>Sign up for your Branchlink.in account</p>
         <?php if(count($errors)>0): ?>
         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="form-row">
            <div class="col-md-12">
               <div class="alert alert-danger alert-dismissible fade show" id="alert-success" role="alert">
                  <?php echo e($error); ?>

                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                  </button>
               </div>
            </div>
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?>
         <form action="/register-data/<?php echo e($tokens); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <input class="form-control" type="text" name="name" placeholder="Your Name" required>
            <input class="form-control" type="email" name="email" placeholder="E-mail Address" required>
            <input class="form-control" type="username" name="username" placeholder="Username" required>
            <input class="form-control" id="password" type="password" name="password" placeholder="Password" required
               pattern=".{8,}">
            <input class="form-control" id="confirm_password" type="password" name="confirm_password"
               placeholder="Confirm your password" required pattern=".{8,}">
            <div class="form-button">
               <button id="submit" type="submit" class="ibtn">Register</button> <a href="/login">Already have an
                  account?</a>
            </div>
         </form>
      </div>
   </div>
</div>
<script>
   var password = document.getElementById("password"),
      confirm_password = document.getElementById("confirm_password");

   function validatePassword() {
      if (password.value != confirm_password.value) {
         confirm_password.setCustomValidity("Passwords Don't Match");
      } else {
         confirm_password.setCustomValidity('');
      }
   }

   password.onchange = validatePassword;
   confirm_password.onkeyup = validatePassword;
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('login.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bintangtobing/Documents/GitHub/branchlink.in/branchlink.in/resources/views/login/register.blade.php ENDPATH**/ ?>