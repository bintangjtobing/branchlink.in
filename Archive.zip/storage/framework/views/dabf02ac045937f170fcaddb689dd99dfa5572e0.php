<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Branchlink.in | Discover all your content on one link</title>
    <link rel="icon" href="images/icon.png">
    <!-- Plugins CSS -->
    <link rel="stylesheet" href="welcome/plugins/bootstrap-4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="welcome/plugins/meanmenu/meanmenu.css">
    <!-- fonts -->
    <link rel="stylesheet" href="welcome/fonts/ep-icon-fonts/css/style.css">
    <link rel="stylesheet" href="welcome/fonts/fontawesome-5/css/all.min.css">
    <!-- Custom Stylesheet -->
    <link rel="stylesheet" href="welcome/css/settings.css">
    <link rel="stylesheet" href="welcome/css/style.css">
</head>

<body>
    <div class="site-wrapper">
        <header class="site-header">
            <div class="container">
                <div class="row justify-content-center align-items-center position-relative">
                    <div class="col-sm-3 col-6 col-lg-2 col-xl-2 order-lg-1">
                        <div class="brand">
                            <a href=""><img src="image/main-logo.png" alt="" /></a>
                        </div>
                    </div>
                    <div class="col-sm-8 col-lg-3 col-xl-3 d-none d-sm-block order-lg-3">
                        <div class="header-btns">
                            <div class="btn-1">
                                <a href="/login">Sign In</a>
                            </div>
                            <div class="btn-2">
                                <a href="/register">Get Started</a>
                            </div>
                        </div>
                    </div>
                    <!-- Menu Block -->
                    <div class="col-sm-1 col-6 col-lg-7 col-xl-6 offset-xl-1 position-static order-lg-2">
                        
                        <div class="mobile-menu"></div>
                    </div>
                </div>
            </div>
        </header>
        <!-- Hero Area  -->
        <section class="hero-area">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 order-lg-2">
                        <div class="hero-image">
                            <img src="welcome/image/hero-image.png" alt="">
                        </div>
                    </div>
                    <div class="col-lg-6 order-lg-1">
                        <div class="hero-content">
                            <h1>Discover all your content to your audience.</h1>
                            <p>Create custom of your archives of links in one page - no purchasing needed.
                            </p>
                            <div class="hero-form">
                                <form action="/register">
                                    <div class="form-group">
                                        <button class="submit-btn">Get Started</button>
                                    </div>
                                    <p class="form-text">Already using Branchlink.in? <a href="/login" class="link">Sign
                                            In</a>
                                    </p>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </section>

        <!-- Features Area  -->
        <section class="feature-section">
            <div class="shape">
                <img src="welcome/image/landing-1-shape.svg" alt="">
            </div>
            <div class="container">
                <div class="section-title text-center">
                    <h2>Simple step to complete your page.</h2>
                </div>
                <div class="row mb-d-30">
                    <div class="col-md-6 col-lg-4 mb--30">
                        <div class="feature-card">
                            <div class="card-icon">
                                <i class="icon icon-users-mm"></i>
                            </div>
                            <div class="card-content">
                                <h3>Create Profile</h3>
                                <p>Whether it’s a small internal app or a new for millions of customers, our design and
                                    development teams.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mb--30">
                        <div class="feature-card">
                            <div class="card-icon">
                                <i class="icon icon-send"></i>
                            </div>
                            <div class="card-content">
                                <h3>Setting All Up Done</h3>
                                <p>Whether it’s a small internal app or a new for millions of customers, our design and
                                    development teams.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mb--30">
                        <div class="feature-card">
                            <div class="card-icon">
                                <i class="icon icon-settings"></i>
                            </div>
                            <div class="card-content">
                                <h3>Share Your Page</h3>
                                <p>Whether it’s a small internal app or a new for millions of customers, our design and
                                    development teams.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </section>

        <!-- Features Area  -->
        <section class="content-section-01">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-5  col-sm-6 col-10">
                        <div class="content-img">
                            <img src="welcome/image/content-image-1.png" alt="">
                        </div>
                    </div>

                    <div class="col-xl-5 offset-xl-1 col-sm-6">
                        <div class="content-right-content">
                            <h2>Our Next Plan: Freely you can see your full statistics data.</h2>
                            <p>
                                Yes. Our next plan is statistics and analytics. You can see your full data of your
                                links. And others plan will be announced on this page.
                            </p>
                            
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <section class="content-section-03">
            <div class="shape">
                <img src="welcome/image/landing-4.svg" alt="">
            </div>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-5 col-lg-6 col-md-5 col-sm-6 col-10">
                        <div class="content-img">
                            <img src="welcome/image/content-image-3.png" alt="">
                        </div>
                    </div>
                    <div class="col-xl-5  offset-xl-1 col-lg-6 col-md-7 col-sm-6 ">
                        <div class="content-left-content">
                            <h2>Increase Your Audience With All of Your Content</h2>
                            <p>
                                Put all of your content here. No worries about stealth, suspicious data because we have
                                already complete our link analytics with secure.
                            </p>
                            <div class="content-bottom-part">
                                <p>Interested to make one?</p>
                                <div class="content-btn">
                                    <a href="/register" class="btn btn--primary">Get Started</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </section>


        <!-- Pricing section -->
        <section class="pricing-section">
            <div class="shape">
                <img src="welcome/image/landing-2-shape.svg" alt="">
            </div>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="section-title text-center">
                            <h2>Don't worries on purchasing</h2>
                            <p>We designed and developed this thing because we know this is will help any people to grow
                                their audiences.</p>
                        </div>
                    </div>
                </div>
                
            </div>
        </section>

        <!-- Footer Section 06 -->
        <div class="footer-section">
            <div class="container">
                

                <div class="row margin-decrese">
                    <div class="col-xl-4 col-lg-5 col-margin">
                        <div class="single-footer">
                            <div class="footer-title">
                                <img src="welcome/image/footer-log.png" alt="footer logo" style="width:150px;">
                            </div>
                            <div class="footer-text">
                                <p>Big, small, online, offline, local. Size doesn't matter. We work on diverse projects
                                    for top brands as well as for cool startups. </p>
                            </div>
                            
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    <!-- Vendor JS-->
    <script src="welcome/plugins/jquery/jquery.min.js"></script>
    <script src="welcome/plugins/jquery/jquery-migrate.min.js"></script>
    <script src="welcome/plugins/bootstrap-4.3.1/js/bootstrap.bundle.js"></script>
    <script src="welcome/plugins/meanmenu/jquery.meanmenu.js"></script>
    <!-- Plugins JS -->
    <script src="welcome/js/active.js"></script>
</body>

</html><?php /**PATH /Users/bintangtobing/Documents/GitHub/branchlink.in/branchlink.in/resources/views/welcome.blade.php ENDPATH**/ ?>